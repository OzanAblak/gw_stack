$ErrorActionPreference='SilentlyContinue'
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem

$root="C:\Users\DELL\Desktop\gw_stack"
$tag="v0.1.2-core"
$outDir=Join-Path $root "artifacts"
$out=Join-Path $outDir ("gw_stack_{0}.zip" -f $tag)

if(!(Test-Path $outDir)){ New-Item -ItemType Directory -Path $outDir | Out-Null }
if(Test-Path $out){ Remove-Item $out -Force 2>$null }

$includes=@(
  "docker-compose.yml",
  "docker-compose.gateway.yml",
  "infra",
  "scripts",
  "docs",
  "docs\publish_checklist.md"
)
$excludeDirs=@("\.git\", "\artifacts\", "\__pycache__\", "\node_modules\", "\.venv\", "\.pytest_cache\")
$excludeExt = @(".log",".tmp",".tsbuildinfo")

$added=0; $scanned=0; $miss=0; $errMsg=""

try{
  $fs = [System.IO.File]::Open($out,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
  $zip = New-Object System.IO.Compression.ZipArchive($fs,[System.IO.Compression.ZipArchiveMode]::Create,$true)

  foreach($inc in $includes){
    $src = Join-Path $root $inc
    if(Test-Path $src -PathType Leaf){
      $rel = $src.Substring($root.Length).TrimStart('\','/')
      $in = [System.IO.File]::OpenRead($src)
      try { $in.CopyTo(($zip.CreateEntry($rel,[System.IO.Compression.CompressionLevel]::Optimal)).Open()); $added++ } finally { $in.Dispose() }
      $scanned++
      continue
    }
    if(Test-Path $src -PathType Container){
      Get-ChildItem -LiteralPath $src -Recurse -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
        $p=$_.FullName; $scanned++
        if($excludeDirs | Where-Object { $p -like ("*{0}*" -f $_) }) { return }
        if($excludeExt -contains $_.Extension) { return }
        $rel = $p.Substring($root.Length).TrimStart('\','/')
        try {
          $in = [System.IO.File]::OpenRead($p)
          try { $in.CopyTo(($zip.CreateEntry($rel,[System.IO.Compression.CompressionLevel]::Optimal)).Open()); $added++ } finally { $in.Dispose() }
        } catch {}
      }
      continue
    }
    $miss++
  }
} catch {
  $errMsg = ($_.Exception.Message -replace '\s+',' ')
} finally {
  if($zip){ $zip.Dispose() }
  if($fs){ $fs.Dispose() }
}

$ok = (Test-Path $out) -and ((Get-Item $out -ErrorAction SilentlyContinue).Length -gt 0)
$size = ($ok)? (Get-Item $out).Length : 0
if(-not $ok -and -not [string]::IsNullOrEmpty($errMsg)){
  Write-Output ("ART={0} OK=NO SIZE=0 ADDED={1} MISS={2} ERR={3}" -f $out,$added,$miss,$errMsg.Substring(0,[Math]::Min(120,$errMsg.Length)))
  exit 1
}
Write-Output ("ART={0} OK={1} SIZE={2} ADDED={3} SCANNED={4} MISS={5}" -f $out,($(if($ok){"YES"}else{"NO"})),$size,$added,$scanned,$miss)
exit ($(if($ok){0}else{1}))
